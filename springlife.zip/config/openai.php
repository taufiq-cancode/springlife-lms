<?php

    return [
        'api_key' => env('OPENAI_API_KEY'),
    ];