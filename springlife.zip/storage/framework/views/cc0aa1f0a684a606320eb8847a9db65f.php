
<?php $__env->startSection('content'); ?>

<style>
    .form-check-input {
        min-width: 1.2em;
    }
</style>


    <div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
      <div class="d-flex flex-wrap justify-content-between gap-3" style="padding-top:0">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Lessons /</span> <?php echo e($lesson->title); ?> </h4>

        <?php if(auth()->check() && auth()->user()->role === 'admin'): ?>
        <div>
            <button type="button" class="btn btn-outline-primary mt-3 mb-4" data-bs-toggle="modal" data-bs-target="#modalEdit">Edit Lesson</button>
        </div>
        <?php endif; ?>

      </div>
      
        <div class="row">
            <div class="col-lg-12">
                <div class="card mb-4">
                   
                    <div class="card-body row g-3">
                        <div class="col-lg-8">
                          <div class="d-flex justify-content-between align-items-center flex-wrap mb-2 gap-1">
                            <div class="me-1">
                              <h4 class="mb-1"><?php echo e($lesson->title); ?></h4>
                            </div>
                          </div>
                          <div class="card academy-content shadow-none border">
                            <div class="p-2">
                                <div class="ratio ratio-16x9">
                                    <?php echo $lesson->link; ?>

                                </div>
                            </div>
                            <div class="card-body">

                                <h5 class="mb-2">About this course</h5>
                                <p class="mb-0 pt-1"><?php echo e($course->description); ?></p>
                                <hr class="my-4">

                                <h5>Resources</h5>

                                <div class="list-group list-group-flush">
                                    <?php $__empty_1 = true; $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <a href="<?php echo e(route('resources.download', ['resourceId' => $resource->id])); ?>" class="list-group-item list-group-item-action">
                                            <i class='bx bxs-file-pdf'></i> <?php echo e($resource->title); ?>

                                            <i class='bx bx-download' style="float:right; color:cornflowerblue"></i>
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <p>No resources available for this course.</p>
                                    <?php endif; ?>
                                </div>
                                            
                              </div>
                          </div>
                        </div>
                        <div class="col-lg-4">
                          <div class="accordion stick-top accordion-bordered course-content-fixed" id="courseContent">
                            <div class="accordion-item shadow-none border mb-0">
                              <div class="accordion-header" id="headingOne">
                                <button type="button" class="accordion-button bg-lighter rounded-0" data-bs-target="#chapterOne" aria-expanded="false" aria-controls="chapterOne">
                                  <span class="d-flex flex-column">
                                    <span class="h5 mb-1">Lessons</span>
                                    <span class="fw-normal">2 / 5 completed</span>
                                  </span>
                                </button>
                              </div>
                              <div id="chapterOne" class="accordion-collapse" data-bs-parent="#courseContent" style="">
                                
                                <div class="accordion-body py-3 border-top">
                                  
                                    <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="form-check d-flex align-items-center mb-3">
                                            <input class="form-check-input" type="checkbox" id="lesson_<?php echo e($lesson->id); ?>" checked="">
                                            
                                            <label for="lesson_<?php echo e($lesson->id); ?>" class="form-check-label ms-3">
                                                <span class="mb-0 h6"><?php echo e($loop->iteration); ?>. <?php echo e($lesson->title); ?></span>
                                                <span class="text-muted d-block"><?php echo e($lesson->duration); ?> min</span>
                                            </label>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                         
                                </div>
                              </div>
                            </div>
                          
                          </div>
                        </div>
                      </div>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->


    <!-- Footer -->
    <footer class="content-footer footer bg-footer-theme">
        <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            ©
            <script>
            document.write(new Date().getFullYear());
            </script> Spring Life Ministry. Developed by
            <a href="https://purplebeetech.com" target="_blank" class="footer-link fw-bolder">Purple Bee Technologies.</a>
        </div>
        </div>
    </footer>
    <!-- / Footer -->

    
    <?php if(auth()->check() && auth()->user()->role === 'admin'): ?>

        <div class="modal fade" id="modalCenter" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalCenterTitle">Add a Lesson</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="<?php echo e(route('lessons.store', ['courseId' => $course->id])); ?>">
                            <?php echo csrf_field(); ?>
        
                            <div class="row">
                                <div class="col mb-3">
                                    <label for="title" class="form-label">Lesson Title</label>
                                    <input type="text" name="title" class="form-control" placeholder="Enter Lesson Title" required>
                                </div>
                            </div>
        
                            <div class="row">
                                <div class="col mb-3">
                                    <label for="lesson_link" class="form-label">Lesson Link</label>
                                    <input type="text" name="link" class="form-control" placeholder="Enter Lesson Youtube Link" required>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col mb-3">
                                    <label for="lesson_link" class="form-label">Lesson Duration</label>
                                    <input type="number" name="duration" class="form-control" placeholder="Enter Lesson Duration" required>
                                </div>
                            </div>

                            <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">
        
                            <div class="modal-footer">
                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Upload lesson</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="modalEdit" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="modalCenterTitle">Edit Course</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <div class="modal-body">

                    <form method="POST" action="<?php echo e(route('courses.update', ['courseId' => $course])); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
    
                        <div class="row">
                            <div class="col mb-3">
                                <label for="nameWithTitle" class="form-label">Course Title</label>
                                <input type="text" id="nameWithTitle" name="title" value="<?php echo e($course->title); ?>" class="form-control" placeholder="Enter Course Title">
                            </div>
                        </div>
    
                        <div class="row">
                            <div class="col mb-3">
                                <label for="nameWithTitle" class="form-label">Course Description</label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" name="description" rows="3"><?php echo e($course->description); ?></textarea>
                            </div>
                        </div>
    
                        <div class="row">
                            <div class="col mb-3">
                                <label for="nameWithTitle" class="form-label">Course Resource Files</label>
                                <input class="form-control" type="file" id="formFileMultiple" name="files[]" multiple="" accept=".pdf">
                            </div>
                        </div>
    
                        <div class="row">
                            <div class="col mb-3">
                                <label for="nameWithTitle" class="form-label">Cover Image</label>
                                <input class="form-control" type="file" name="cover_image" id="formFileMultiple" accept=".png, .jpg, .jpeg">
                            </div>
                        </div>
    
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Update course</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>

    <?php endif; ?>  

    <div class="content-backdrop fade"></div>
    </div>
          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.theme-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\springlife-lms\resources\views/lessons/view.blade.php ENDPATH**/ ?>