
<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-lg-8 mb-4 order-0">
            <div class="card">
                <div class="d-flex align-items-end row">
                    <div class="col-sm-7">
                        <?php if(auth()->check() && auth()->user()->role === 'admin'): ?>

                            <div class="card-body">
                                <h5 class="card-title text-primary">Welcome, Admin <?php echo e(Illuminate\Support\Str::title(auth()->user()->firstname)); ?>!👋🏻</h5>
                                <p class="mb-4">
                                    You have administrative privileges. You can manage courses, resources and users.
                                </p>    
                                <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-sm btn-outline-primary">Manage Courses</a>
                            </div>
                        
                        <?php else: ?>

                            <?php if(session('first_time_registered')): ?>
                                <div class="card-body">
                                    <h5 class="card-title text-primary">Welcome, <?php echo e(Illuminate\Support\Str::title(auth()->user()->firstname)); ?>!👋🏻</h5>
                                    <p class="mb-4">
                                        We are glad you made it here. Get started by exploring our amazing study courses!
                                    </p>
                                    <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-sm btn-outline-primary">View Courses</a>
                                </div>
                            <?php else: ?>
                                <div class="card-body">
                                    <h5 class="card-title text-primary">Welcome Back, <?php echo e(Illuminate\Support\Str::title(auth()->user()->firstname)); ?>!👋🏻</h5>
                                    <p class="mb-4">
                                        We love to have you back. Keep it up and get your certificates!
                                    </p>
                                    <a href="javascript:;" class="btn btn-sm btn-outline-primary">Continue Lessons</a>
                                </div>
                            <?php endif; ?>

                        <?php endif; ?>

                    </div>
                <div class="col-sm-5 text-center text-sm-left">
                    <div class="card-body pb-0 px-0 px-md-4">

                        <?php if(auth()->check()): ?>
                            <?php if(auth()->user()->gender === 'male'): ?>
                                <img src="../assets/img/illustrations/man-with-laptop-light.png" height="140" />
                            <?php else: ?>
                                <img src="../assets/img/illustrations/woman-with-laptop.png" height="140" />
                            <?php endif; ?>
                        <?php endif; ?>

                    </div>
                </div>
                </div>
            </div>
            </div>
            <div class="col-lg-4 col-md-4 order-1">
            <div class="row">

                <?php if(auth()->check() && auth()->user()->role === 'admin'): ?>

                    <div class="col-lg-6 col-md-12 col-6 mb-4">
                        <div class="card">
                            <div class="card-body">
                            <div class="card-title d-flex align-items-start justify-content-between">
                                <div class="avatar flex-shrink-0">
                                    <img src="../assets/img/icons/unicons/chart-success.png" alt="chart success" class="rounded"/>
                                </div>
                            </div>
                            <span class="fw-semibold d-block mb-1">Total Courses</span>
                            <h5 class="card-title mb-2"><?php echo e($totalCourses); ?></h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-12 col-6 mb-4">
                        <div class="card">
                            <div class="card-body">
                            <div class="card-title d-flex align-items-start justify-content-between">
                                <div class="avatar flex-shrink-0">
                                    <img src="../assets/img/icons/unicons/wallet-info.png" alt="Credit Card" class="rounded" />
                                </div>
                            </div>
                            <span class="fw-semibold d-block mb-1">Total Lessons</span>
                            <h5 class="card-title text-nowrap mb-1"><?php echo e($totalLessons); ?></h5>
                            </div>
                        </div>
                    </div>

                <?php else: ?>

                    <div class="col-lg-6 col-md-12 col-6 mb-4">
                        <div class="card">
                            <div class="card-body">
                            <div class="card-title d-flex align-items-start justify-content-between">
                                <div class="avatar flex-shrink-0">
                                    <img src="../assets/img/icons/unicons/chart-success.png" alt="chart success" class="rounded"/>
                                </div>
                            </div>
                            <span class="fw-semibold d-block mb-1">Completed Lessons</span>
                            <h5 class="card-title mb-2"><?php echo e($completedLessons); ?></h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-12 col-6 mb-4">
                        <div class="card">
                            <div class="card-body">
                            <div class="card-title d-flex align-items-start justify-content-between">
                                <div class="avatar flex-shrink-0">
                                    <img src="../assets/img/icons/unicons/wallet-info.png" alt="Credit Card" class="rounded" />
                                </div>
                            </div>
                            <span class="fw-semibold d-block mb-1">Total Lessons</span>
                            <h5 class="card-title text-nowrap mb-1"><?php echo e($totalLessons); ?></h5>
                            </div>
                        </div>
                    </div>

                <?php endif; ?>
            </div>
            </div>
        </div>

        <div class="row">
        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="card-header d-flex flex-wrap justify-content-between gap-3">
                    <div class="card-title mb-0 me-1">
                        <h5 class="mb-1">Courses</h5>
                    </div>
                </div>

                <div class="card-body">
                    <div class="row gy-4 mb-4">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $totalLessons = $course->lessons()->count();
                                $totalDuration = $course->lessons()->sum('duration'); 
                            ?>

                            <div class="col-sm-6 col-lg-4">
                                <div class="card p-2 h-100 shadow-none border">

                                    <div class="rounded-2 text-center mb-3">
                                        <a href="<?php echo e(route('courses.view', ['courseId' => $course->id])); ?>"><img class="img-fluid" src="storage/<?php echo e($course->cover_image ?? '../assets/img/online-learning.png'); ?>" alt="<?php echo e($course->title); ?>"></a>
                                    </div>
                                    
                                    <div class="card-body p-3 pt-2">

                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <span class="badge bg-label-primary"><i class='bx bx-time'></i> <?php echo e($totalDuration); ?> Minutes</span>
                                            <span class="badge bg-label-secondary"><i class='bx bxs-videos'></i> <?php echo e($totalLessons); ?> Lessons</span>
                                        </div>
                                        
                                        <a href="<?php echo e(route('courses.view', ['courseId' => $course->id])); ?>" class="h5"><?php echo e($course->title); ?></a>
                                        <p class="mt-2"> <?php echo e($course->description); ?></p>
                                        
                                        <?php if(auth()->check() && auth()->user()->role === 'user'): ?>
                                            <p class="d-flex align-items-center"><i class="bx bx-time-five me-2"></i><?php echo e(round($course->getUserProgress(Auth::user())['progressPercentage'])); ?>% Completed</p>
                                            <div class="progress mb-4" style="height: 8px">
                                                <div class="progress-bar w-<?php echo e(round($course->getUserProgress(Auth::user())['progressPercentage'])); ?>" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                            <a href="<?php echo e(route('courses.view', ['courseId' => $course->id])); ?>" style="width: 100%;" class="btn btn-outline-primary">Continue Lessons <i class='bx bx-chevron-right'></i></a>
                                        <?php endif; ?>

                                        <?php if(auth()->check() && auth()->user()->role === 'admin'): ?>
                                            <div class="d-flex gap-2">
                                                <a href="<?php echo e(route('courses.view', ['courseId' => $course->id])); ?>" style="width: 100%;" class="btn btn-outline-primary">View</a>
                                                
                                                <form method="POST" action="<?php echo e(route('courses.delete', ['courseId' => $course->id])); ?>" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                
                                                    <button type="submit" onclick="return confirm('Are you sure you want to delete this course?')" style="width: 100%;" class="btn btn-outline-danger">Delete</button>
                                                </form> 
                                                    
                                            </div>
                                        <?php endif; ?>

                                    </div>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        </div>
    </div>
    <!-- / Content -->


    <!-- Footer -->
    <footer class="content-footer footer bg-footer-theme">
        <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            ©
            <script>
            document.write(new Date().getFullYear());
            </script> Spring Life Ministry. Developed by
            <a href="https://purplebeetech.com" target="_blank" class="footer-link fw-bolder">Purple Bee Technologies.</a>
        </div>
        </div>
    </footer>
    <!-- / Footer -->

    <div class="content-backdrop fade"></div>
    </div>
          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.theme-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\springlife-lms\resources\views/dashboard.blade.php ENDPATH**/ ?>